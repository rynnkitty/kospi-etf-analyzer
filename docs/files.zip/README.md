# KOSPI ETF Sector Analyzer

> 코스피 섹터별 ETF 보유종목 & 밸류에이션(PER/PBR) 대시보드

## 소개

KOSPI 시장의 섹터별 ETF가 보유한 상위 종목들의 PER, PBR 등 밸류에이션 지표를 한눈에 비교할 수 있는 웹 대시보드입니다. GitHub Actions가 매일 장 마감 후 KRX에서 최신 데이터를 자동 수집하고, GitHub Pages로 정적 배포합니다.

## 주요 기능

- **섹터별 ETF 대시보드**: 10개 KOSPI 섹터의 밸류에이션 요약 한눈에 보기
- **ETF 보유종목 조회**: 각 ETF의 상위 보유종목과 비중 확인
- **종목별 PER/PBR 표시**: 보유종목의 핵심 밸류에이션 지표 + 색상 코딩
- **섹터 비교 차트**: 섹터별 평균 PER/PBR 바 차트, 히트맵
- **필터 & 정렬**: PER/PBR 범위 필터, 종목 검색, 다중 정렬
- **자동 갱신**: 매일 18:00 KST GitHub Actions가 데이터 수집 + 배포

## 기술 스택

| 분류 | 기술 |
|------|------|
| 프론트엔드 | Next.js 14 (App Router) + TypeScript + TailwindCSS v4 + shadcn/ui |
| 차트 | Recharts |
| 상태 관리 | Zustand |
| 데이터 수집 | Python 3.12 + requests + pandas |
| CI/CD | GitHub Actions |
| 배포 | GitHub Pages (정적 사이트) |
| 테스트 | Vitest + Playwright |

## 시작하기

### 사전 요구사항

- Node.js 20+
- Python 3.12+
- npm 10+

### 설치 및 실행

```bash
# 저장소 클론
git clone https://github.com/<username>/kospi-etf-analyzer.git
cd kospi-etf-analyzer

# 프론트엔드 의존성 설치
npm install

# Python 의존성 설치
cd scripts && pip install -r requirements.txt && cd ..

# 데이터 수집 (최초 1회)
cd scripts
python collect_etf_list.py
python collect_holdings.py
python collect_valuation.py
python merge_data.py
cd ..

# 개발 서버 실행
npm run dev
```

### 빌드 & 배포

```bash
# 정적 빌드
npm run build

# 빌드 결과: /out 디렉토리 → GitHub Pages 배포
```

## 프로젝트 구조

```
├── .github/workflows/    # GitHub Actions (데이터 수집 + 배포)
├── scripts/              # Python 데이터 수집 스크립트
├── public/data/          # 수집된 JSON 데이터 파일
├── src/
│   ├── app/              # Next.js 페이지 (대시보드, 섹터, ETF, 종목)
│   ├── components/       # React 컴포넌트 (기능별 분리)
│   ├── hooks/            # 커스텀 훅 (데이터 로딩, 필터)
│   ├── store/            # Zustand 스토어
│   ├── lib/              # 유틸리티 함수
│   ├── types/            # TypeScript 타입 정의
│   └── constants/        # 상수 (섹터 분류, 임계값)
├── tests/                # 테스트 (unit, integration, e2e)
├── docs/                 # 상세 기획서 (PRD)
├── CLAUDE.md             # AI 컨텍스트 파일
├── MANUAL.md             # Claude Code 실행 매뉴얼
├── PROGRESS.md           # 개발 진행 기록
└── ROADMAP.md            # 개발 로드맵
```

## 데이터 출처

- [KRX 정보데이터시스템](https://data.krx.co.kr/) — ETF 시세, PDF(보유종목), 개별종목 PER/PBR

## 라이선스

MIT

## 기여

이슈 및 PR 환영합니다. 기여 전 `CLAUDE.md`의 코드 컨벤션을 확인해주세요.
